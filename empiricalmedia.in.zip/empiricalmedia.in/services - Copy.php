<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	<!-- title -->
	<title>Empirical Media- Services</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<!-- Simple-line-icons -->
	<link rel="stylesheet" href="assets/css/simple-line-icons.css">
	<!-- Animate -->
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- Responsive CSS -->
	<link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body id="top">
	<!-- MAIN START -->
	 <div class="main_wrapper pages_main_wrapper parallax background-image" data-src="assets/img/banner-2.jpg">
		<!-- NAVBAR START-->
		<?php include('include/header1.php');?>
		<!-- NAVBAR END-->
		<!-- PAGE BREADCAMB START -->
		<div class="landing_content">
			<div class="display_table">
				<div class="display_table_cell">
					<div class="container">
						<div class="row">
							<div class="col text-center">
								<h5 class="page_breadcamb">Services</h5>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- PAGE BREADCAMB END -->
	</div>
	<!-- MAIN END -->
	<!-- SERVICE START -->
	<div class="wrapper service_wrapper pt100">
		<div class="container">
			<div class="row">
				<div class="col">
				  
					<div class="wrapper_heading_text">
						<h2 class="primary_text">Services</h2>
						<h4 class="secondary_text">Telling your compelling stories to the World</h4>
					</div>
				</div>
			</div>
			<div class="row">

				<div class="col-lg-4 col-md-6">
					<div class="service_item_02">					
						<h4>Tv & Media Planning & Buying</h4>
						<p class="pera_text">We plan and buy media across all formats of television and digital. Based on our innovative techniques, past experiences and your valuable inputs, we develop an effective campaign.</p>
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service_item_02">					   
						<h4>Print Media Advertising</h4>
						<p class="pera_text">We created a guide of the best Print medias to help you make the right media choices. We review, look through notable projects, and compare prices to find the best media for your brand promotionals activities.</p>
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service_item_02">					   
						<h4>Full service Digital Marketing</h4>
						<p class="pera_text">Understanding the market and consumer behavior help us to achieve the best ROI through, Search Engine Optimization, Social & Pay Per Click Advertising, Social Media Management, Blogging and Email Marketing.<a class="onio_btn1 onio_btn_alt" href="https://www.goldenunicon.com/" target="_blank">Know More</a></p>
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service_item_02">						
						<h4>Design &  Development</h4>
						<p class="pera_text">We provide design solutions (including Logo, Banner, Brochure & PPT Presentation). We developed custom made effective LCPs, web, E-commerce sites & Mobile App in all platforms using the best technology.</p>
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service_item_02">
				   
						<h4>Outdoor Advertising</h4>
						<p class="pera_text">Focused on customer needs, committed to delivering research and information that helps create a program to achieve your marketing goals,Whether you want to create a buzz, reach a mass audience or direct locals to your front door.</p>
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service_item_02">
					  
						<h4>Event Management</h4>
						<p class="pera_text">Focused on customer needs, committed to delivering research and information that helps create a program to achieve your marketing goals,Whether to create a buzz, reach a mass or direct locals to your front door.<a class="onio_btn1 onio_btn_alt" href="https://www.goldenunicon.com/" target="_blank">Know More</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- SERVICE END -->
	<!-- CONTACT US START -->
	<div class="wrapper hire_us_wrapper parallax mb100">
		<div class="container">
			<div class="row align-items-center justify-content-center">
				<div class="col-md-12 text-center">
					<h2>Let's talk</h2>
				   <h3>Stop By & Say "Hi", Or Drop Us A Note</h3>
					<a class="onio_btn" href="contact.php">Start Talk</a>
				</div>
			</div>
		</div>
	</div>
	<!-- CONTACT US END -->
	<!-- FOOTER START -->
	   <?php include('include/footer.php');?>
  <a class="go_top" href="services.php#top"><i class="icon-arrow-up"></i></a>

	<!-- FOOTER END -->

	<!-- jQuery JS-->
	<script src="assets/js/jquery.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Plugins JS -->
	<script src="assets/js/plugins.js"></script>
	<!-- Main JS -->
	<script src="assets/js/main.js"></script>
	
</body>

</html>