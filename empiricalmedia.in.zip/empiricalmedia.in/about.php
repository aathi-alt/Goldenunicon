<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- title -->
   <title>Empirical Media - About</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<!-- Simple-line-icons -->
	<link rel="stylesheet" href="assets/css/simple-line-icons.css">
	<!-- Swiper -->
	<link rel="stylesheet" href="assets/css/swiper.min.css">
	<!-- Magnific-popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<!-- Animate -->
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- Responsive CSS -->
	<link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body id="top">
	<!-- MAIN START -->
	<div class="main_wrapper pages_main_wrapper parallax background-image" data-src="assets/img/banner-1.jpg">
		<!-- NAVBAR START-->
		<?php include('include/header1.php');?>
		<!-- NAVBAR END-->
		<!-- PAGE BREADCAMB START -->
		<div class="landing_content">
			<div class="display_table">
				<div class="display_table_cell">
					<div class="container">
						<div class="row">
							<div class="col text-center">
								<h5 class="page_breadcamb">About</h5>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- PAGE BREADCAMB END -->
	</div>
	<!-- MAIN END -->
	<!-- ABOUT START -->
	<div class="wrapper about_wrapper about_wrapper_two">
		<div class="container">
			<div class="row pb-5">
				<div class="col-md-6">
					<div class="about_header_text mb30-sm">
						<h1 class="primary_text">EMPIRICAL MEDIA</h1>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Vision</h4>
						<p class="pera_text">To be the preferred Media Planning, Consulting, Buying & Execution partner providing holistic and biz growth-centric branding strategies and solutions.</p>
					</div>
				</div>

				<div class="col-md-6">
					<div class="about_header_text mb30-sm">
						<h1 class="primary_text">&nbsp;</h1>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Mission</h4>
						<p class="pera_text">Empower the Industry as a Leader; design, develop and execute Solid & Pragmatic Media Buying & Planning for the clients. Define and advocate Advertising & Media values, Principles and Best Practices<br/>Continue to strengthen the Eco System by building strong media partners in local markets and data analytics; provide personalized and relevant customer experience<br/>Embrace Cutting-edge technology to help clients optimizing Media Planning & Execution Cost </p>
					</div>
				</div>
			</div>


			<div class="row">
				<div class="col-md-12">
					<div class="about_header_text mb30-sm">
						<h1 class="primary_text">Core Values</h1>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Integrity</h4>
						<p class="pera_text">Beyond building business & solutions, we strive towards defining the best practices that lead to transparency in processes and communication. Integrity is assured in terms of Cost, Quality, Delivery, External & Internal stakeholder management.</p><br/>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Channel Performance Assessment beyond Trends</h4>
						<p class="pera_text">Our primary focus is to create a clear cut, scientific and manageable Media buying strategy for your ‘real’ time growth. We invest quality resources in assessing the channel performance in various phases for informed decision making.</p><br/>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Complete Knowledge Sharing before Execution</h4>
						<p class="pera_text">‘Transparency’ is the critical tool that brings us repeated clientele. The historical data analysis helps in providing clear cut information with complete transparency on the Forecast, ROI and Cost. No push strategy when it comes to budget or a product rather we offer a pragmatic and solution-based approach.</p><br/>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Scientific Approach to the Campaign</h4>
						<p class="pera_text">We use numerous models for data gathering, analysis and reporting using cutting edge technologies. Such scientific approach leads to successful campaign design, execution and enhanced drive outcome. </p><br/>
						<h4 style="margin-bottom: 20px;" class="secondary_text">Cost Optimization & Competitive Pricing for High-Value Solution</h4>
						<p class="pera_text">Our competitive pricing and the high quality result is our core forte; our in-depth data analysis based strategy execution helps in optimizing your advertising spend.</p>
					</div>
				</div>			
				
			</div>




		</div>
		<div class="container">
			<div class="about_content about_content_two">
			  <!--   <div class="row align-items-center">
					<div class="col-md-6 mb30-sm">
						<h1 class="primary_text">Lorem ipsum</h1>
						<h4 class="secondary_text">Lorem ipsum dolor sit amet</h4>
						<p class="pera_text"> > Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
						<p class="pera_text"> > Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					</div>
					<div class="col-md-6">
					   
						<a href="javascript:;" class="popup-youtube">
							<div class="about_content_img">
								<img class="img-fluid" src="assets/img/about2.jpg" alt="about2">
								<div class="play_btn">
									<img src="assets/img/play-icon.png" alt="play-icon">
									<span>Play</span>
								</div>
							</div>
						</a>
					</div>
				</div> -->
				<h1 class="primary_text">Why Choose Us</h1>
				
				<img src="assets/img/about-us.jpg" width="100%" alt="about">
			</div>
		</div>
	</div>
	<!-- ABOUT  END -->
	
	<!--CONTACT US START -->
	<div class="wrapper hire_us_wrapper parallax">
		<div class="container">
			<div class="row align-items-center justify-content-center">
				<div class="col-md-12 text-center">
					<h2>Let's talk</h2>
					<h3>Stop By & Say "Hi", Or Drop Us A Note</h3>
					<a class="onio_btn" href="contact.php">Start Talk</a>
				</div>
			</div>
		</div>
	</div>
	<!-- CONTACT US END -->
   <!-- FAQ  START -->
	<div class="wrapper faq_wrapper">
		<div class="container">
			<div class="row">
				<div class="col pb-5">
				   
					<div class="wrapper_heading_text">
						<h2 class="primary_text">Team Info</h2>
					</div>
				</div>
			</div>


			<div class="row pb-5">
				<div class="col-md-6">
					<div class="about_header_text mb30-sm">
						<h4 style="margin-bottom: 20px;" class="secondary_text">Muralidhar Sampanna, Sales & Marketing Director </h4>
						<p class="pera_text">A sales and marketing leader, Muralidhar Sampanna builds clientele for Empirical Media. Muralidhar comes with over 18 years of experience managing demographically diverse segments. His expertise include but not limited to Market Data Analysis, Target segment identification, New Market Penetration, P&L management, Product launches and customised communication strategy development.<br/>
						Muralidhar takes triumph in building creative and workable solutions for the clients that help in mutually reaping huge ROI.</p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="about_header_text mb30-sm">
						<h4 style="margin-bottom: 20px;" class="secondary_text">Ananth Vellal, Business Director</h4>
						<p class="pera_text">An Industry Expert, Anand Vellal heads Empirical Media as a Business director. He utilizes over 20 years Industry leadership experience in Advertising & Marketing in achieving overall management excellence for Empirical Media. Backed with MBA, Ananth holds strong expertise in Branding, OOH, Client Engagement and Networking. The relationship models he built with IBM, Britannia, Arvind Mills, CREDAI, TVS motors are utilised in developing the delivery models for Empirical Media.<br/> Ananth strives towards strengthening the existing and new market operations & related processes.</p>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="about_header_text mb30-sm">
						<h4 style="margin-bottom: 20px;" class="secondary_text">Sandhya Rai, Business Strategy</h4>
						<p class="pera_text">A strategic leader with huge Industry experience, Sandhya Rai leads the designs, development and execution of Media Planning & Strategy roadmap. With MBA in Advertising & Marketing and huge hands-on experience working with Broadcast Networks like Zee, Viacom18 and Times, Sandhya possess a treasure full of knowledge and expertise. The client management expertise include managing clients such as HUL, GSK, P & G, J&J, Dabur, Nestle, Pepsi, RB and many known brands. <br/> Sandhya endeavours in enhancing the existing client accounts and building new businesses through innovative and pragmatic strategies.</p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="about_header_text mb30-sm">
						<h4 style="margin-bottom: 20px;" class="secondary_text">Abhiram M B, Head, Operations & Finance</h4>
						<p class="pera_text">A thought leader with over 17 years of Industry & Entrepreneurial experience, Abhiram M B builds operational excellence and manages Finance function. Instrumental in setting up retail Fuel outlets for Reliance Industries, managing distributors followed by an entrepreneurial journey in hospitality services, Abhiram brings his expertise in operations, vendor management, stakeholder management and networking. He is also the director in Laundry labs India Pvt Ltd.,<br/> Abhiram works towards implementing processes, systems to enhance efficiency and optimize cost 7 effort.</p>
					</div>
				</div>
			</div>



			









		</div>
	</div>
	<!-- FAQ END -->
	
	<!-- BRAND END -->
	<div class="wrapper brand_wrapper">
		<div class="container">
			<div class="swiper-container brand">
				<div class="swiper-wrapper">
					<!-- Clients Images -->
					<img class="swiper-slide img-fluid" src="assets/img/brands/client1.jpg" alt="client1">
					<img class="swiper-slide img-fluid" src="assets/img/brands/client2.jpg" alt="client2">
					<img class="swiper-slide img-fluid" src="assets/img/brands/clinet3.jpg" alt="client3">
					<img class="swiper-slide img-fluid" src="assets/img/brands/client4.jpg" alt="client4">
					<img class="swiper-slide img-fluid" src="assets/img/brands/client5.jpg" alt="client5">
					<img class="swiper-slide img-fluid" src="assets/img/brands/client6.jpg" alt="client6">
				</div>
			</div>
		</div>
	</div>
	<!-- BRAND END -->
	<!-- FOOTER START -->
   <?php include('include/footer.php');?>
   <a class="go_top" href="about.php#top"><i class="icon-arrow-up"></i></a>

	<!-- FOOTER END -->

	<!-- jQuery JS-->
	<script src="assets/js/jquery.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Swiper JS -->
	<script src="assets/js/swiper.min.js"></script>
	<!-- Plugins JS -->
	<script src="assets/js/plugins.js"></script>
	<!-- Main JS -->
	<script src="assets/js/main.js"></script>
</body>

</html>