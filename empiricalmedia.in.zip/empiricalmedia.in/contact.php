<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
	<!-- title -->
    <title>Empirical Media- Contact</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Simple-line-icons -->
    <link rel="stylesheet" href="assets/css/simple-line-icons.css">
    <!-- Swiper -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- Magnific-popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body id="top">
    <!-- MAIN  START -->
      <div class="main_wrapper pages_main_wrapper parallax background-image" data-src="assets/img/talk2.jpg">
        <!-- NAVBAR START-->
         <?php include('include/header1.php');?>
        <!-- NAVBAR END-->
        
        <!-- PAGE BREADCAMB START -->
        <div class="landing_content">
            <div class="display_table">
                <div class="display_table_cell">
                    <div class="container">
                        <div class="row">
                            <div class="col text-center">
                                <h5 class="page_breadcamb">Contact</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- PAGE BREADCAMB END -->
    </div>
    <!-- MAIN END -->

    <!-- CONTACT START -->
    <div class="wrapper pt100">
        <div class="container">
            <div class="row">
                <div class="col">
                   
                    <div class="wrapper_heading_text">
                        <h2 class="primary_text">Contact us</h2>
                       <h4 class="secondary_text">Tell Us Your Dream.</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="contact_info_wrapper">
                        <div class="contact_info">
                            <h5>Email Id</h5>
                            <p>sales@empiricalmedia.in</p>
                        </div>
                        <div class="contact_info">
                            <h5>Phone</h5>
                            <p>+91 9845914121</p>
                        </div>
                        <div class="contact_info">
                            <h5>Address</h5>
                            <p>Empirical Media Pvt. Ltd, #403/404, 4TH Floor, Brigade Business Suites, Above Coffee Day,<br> Near Ashok Pillar, Jayanagar 2nd Block, <br>
                            Bengaluru - 560011</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="contact_form">
                        <form id="contact-form" action="#" method="#">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="name">Name</label>
                                    <input id="name" class="contact-input" type="text" name="name" placeholder="Full Name" required="">
                                </div>
                                <div class="col-md-6">
                                    <label for="email">Email</label>
                                    <input id="email" class="contact-input" type="email" name="email" placeholder="Your Email"  required="">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="mobile">Mobile</label>
                                    <input id="mobile" class="contact-input" type="text" name="mobile" placeholder="Mobile Number"  required="">
                                </div>
                                <div class="col-md-12">
                                    <label class="t_area" for="msg">Message</label>
                                    <textarea id="msg" class="contact-input" name="message" placeholder="Tell Something!"  required=""></textarea>
                                </div>
                            </div>
                            <div class="text-center">
                                <button name="submit" class="contact_btn" type="submit">SEND 
                                    <i class="icon-arrow-right"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTACT END -->

    <!-- MAP START -->
    <div class="container">
        <div class="row">
            <div class="col">
                <div id="map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.4483303206607!2d77.58277171482172!3d12.943138590874549!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15e1a8aa5623%3A0xd1c9d3271cfa59b9!2sEmpirical%20Media%20Pvt%20Ltd!5e0!3m2!1sen!2sin!4v1570009079471!5m2!1sen!2sin" width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
            </div>
        </div>
    </div>
    <!-- MAP END -->

    <!-- FOOTER START -->
       <?php include('include/footer.php');?>
       <a class="go_top" href="contact.php#top"><i class="icon-arrow-up"></i></a>

    <!-- FOOTER END -->

   
 <script src="assets/js/gmap_light.js"></script>
    <!-- jQuery JS-->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>
