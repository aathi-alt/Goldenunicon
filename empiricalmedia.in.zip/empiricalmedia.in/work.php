<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
	<!-- title -->
 <title>Empirical Media- Work</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Simple-line-icons -->
    <link rel="stylesheet" href="assets/css/simple-line-icons.css">
    <!-- Magnific-popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Animate -->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body id="top">
    <!-- MAIN START -->
     <div class="main_wrapper pages_main_wrapper parallax background-image" data-src="assets/img/banner-3.jpg">
        <!-- NAVBAR START-->
        <?php include('include/header1.php');?>
        <!-- NAVBAR END-->
        <!-- PAGE BREADCAMB START -->
        <div class="landing_content">
            <div class="display_table">
                <div class="display_table_cell">
                    <div class="container">
                        <div class="row">
                            <div class="col text-center">
                                <h5 class="page_breadcamb">Work</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- PAGE BREADCAMB END -->
    </div>
    <!-- MAIN END -->
    <!-- WORKS START -->
    <div class="wrapper works_wrapper pt100">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="wrapper_heading_text">
                     <h2 class="primary_text">Our Sample Works</h2>
                       <h4 class="secondary_text">Just find what works for you.</h4>
                    </div>
                </div>
            </div>
            <div class="row filters">
                <div class="col-md-4 col-sm-12 text-md-left text-sm-center">
                 
              </div>
                <div class="col-md-8 col-sm-12">
                  
                </div>
            </div>
            <div class="row works works_masonry zoom-gallery">
                
                <div class="col-lg-6 col-md-6 single_work grap">
                    
                    <a class="zoom_image" href="assets/img/works_masonry/work1.jpg">
                        <span class="icon-size-fullscreen"></span>
                        
                        <img class="img-fluid" src="assets/img/works_masonry/work1.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
                
                <div class="col-lg-6 col-md-6 single_work web dev">
                  
                    <a class="zoom_image" href="assets/img/works_masonry/work3.jpg">
                        <span class="icon-size-fullscreen"></span>
                      
                        <img class="img-fluid" src="assets/img/works_masonry/work3.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
               
                <div class="col-lg-6 col-md-6 single_work grap">
    
                    <a class="zoom_image" href="assets/img/works_masonry/work2.jpg">
                        <span class="icon-size-fullscreen"></span>
        
                        <img class="img-fluid" src="assets/img/works_masonry/work2.jpg" alt="work2">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
                
                <div class="col-lg-6 col-md-6 single_work dev grap">
                    
                    <a class="zoom_image" href="assets/img/works_masonry/wokr4.jpg">
                        <span class="icon-size-fullscreen"></span>
                        
                        <img class="img-fluid" src="assets/img/works_masonry/wokr4.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
             
                <div class="col-lg-6 col-md-6 single_work web">
                    
                    <a class="zoom_image" href="assets/img/works_masonry/work4.jpg">
                        <span class="icon-size-fullscreen"></span>
                        
                        <img class="img-fluid" src="assets/img/works_masonry/work4.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
                
                <div class="col-lg-6 col-md-6 single_work web dev">
                    
                    <a class="zoom_image" href="assets/img/works_masonry/work2.jpg">
                        <span class="icon-size-fullscreen"></span>
                        
                        <img class="img-fluid" src="assets/img/works_masonry/work2.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
               
                <div class="col-lg-6 col-md-6 single_work web grap">
                 
                    <a class="zoom_image" href="assets/img/works_masonry/work1.jpg">
                        <span class="icon-size-fullscreen"></span>
                     
                        <img class="img-fluid" src="assets/img/works_masonry/work1.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
             
                <div class="col-lg-6 col-md-6 single_work web">
                   
                    <a class="zoom_image" href="assets/img/works_masonry/work1.jpg">
                        <span class="icon-size-fullscreen"></span>
                       
                        <img class="img-fluid" src="assets/img/works_masonry/work1.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                        <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
             
                <div class="col-lg-6 col-md-6 single_work web grap">
                  
                    <a class="zoom_image" href="assets/img/works_masonry/work2.jpg">
                        <span class="icon-size-fullscreen"></span>
                      
                        <img class="img-fluid" src="assets/img/works_masonry/work2.jpg" alt="work1">
                    </a>
                    <div class="work_info">
                       <p>Lorem</p>
                        <a href="javascript:;"><span class="icon-link"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- WORKS END -->
    <!-- CONTACT US START -->
    <div class="wrapper hire_us_wrapper parallax mb100">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-12 text-center">
                    <h2>Let's talk</h2>
                   <h3>Stop By & Say "Hi", Or Drop Us A Note</h3>
                    <a class="onio_btn" href="contact.php">Start Talk</a>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTACT US END -->
    <!-- FOOTER START -->
      <?php include('include/footer.php');?>
      <a class="go_top" href="work.php#top"><i class="icon-arrow-up"></i></a>

    <!-- FOOTER END -->

    <!-- jQuery JS-->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>