<div class="wrapper footer_wrapper">
        <div class="container">
            <div class="row">
                <!-- Footer About -->
                <div class="col-lg-4 col-md-6">
                   <a href="index.php"><img src="assets/img/logo5.png" alt="logo"></a>
                    <p class="pera_text">The world’s leading media & entertainment companies understand that their success is driven by both art and science.</p>
                    <a href="about.php" class="onio_btn onio_btn_alt">About Us</a>
                </div>
                <!-- Footer Links -->
                <div class="col-lg-4 col-md-6">
                    <h4>Useful Links</h4>
                    <ul class="list-unstyled footer_links">
                        <li><a href="index.php"><span class="icon-arrow-right"></span>Home</a></li>
                        <li><a href="about.php"><span class="icon-arrow-right"></span>About</a></li>
                        <li><a href="services.php"><span class="icon-arrow-right"></span>Services</a></li>
                        
                        <li><a href="work.php"><span class="icon-arrow-right"></span>Work</a></li>
                        <li><a href="contact.php"><span class="icon-arrow-right"></span>Contact</a></li>
                    </ul>
                </div>
                <!-- Footer Contact Info -->
                <div class="col-lg-4 col-md-6">
                    <h4>Contact Info </h4>
                    <p><span class="icon-location-pin"></span>Empirical Media Pvt. Ltd, #403/404, 4TH Floor, Brigade Business Suites, Above Coffee Day,<br> Near Ashok Pillar, Jayanagar 2nd Block,<br> 
                    Bengaluru - 560011</p>
                    <p><span class="icon-envelope"></span>  sales@empiricalmedia.in</p>
                    <p><span class="icon-phone"></span>  +91 9845914121</p>
                    <div class="footer_socials">
                        <a href="javascript:;"><span class="icon-social-facebook"></span></a>
                        <a href="javascript:;"><span class="icon-social-twitter"></span></a>
                        <a href="javascript:;"><span class="icon-social-google"></span></a>
                        <a href="javascript:;"><span class="icon-social-youtube"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    <!-- Footer Copyright -->
    <div class="footer_bottom text-center">
        <span> Design by <a href="https://www.goldenunicon.com/" target="_blank">Golden Unicon</a> <br> All Right Reserved</span>
    </div>