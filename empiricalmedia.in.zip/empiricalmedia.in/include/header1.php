        <nav>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-2 col-md-2 col-6">
                        <!-- Logo -->
                        <a class="logo" href="index.php"><img src="assets/img/logo5.png"></a>
                    </div>
                    <div class="col-lg-10 col-md-10 col-6 text-right">
                        <!-- Main Menu-->
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="work.php">Works</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                        <!-- Responsive Menu Toggle Button-->
                        <div class="menu_btn menu_btn_index d-lg-none d-xl-none">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </nav>