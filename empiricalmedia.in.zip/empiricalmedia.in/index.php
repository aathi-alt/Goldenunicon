<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- title -->
	<title>Empirical Media</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<!-- Simple-line-icons -->
	<link rel="stylesheet" href="assets/css/simple-line-icons.css">
	<!-- Swiper -->
	<link rel="stylesheet" href="assets/css/swiper.min.css">
	<!-- Magnific-popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<!-- Animate -->
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- Responsive CSS -->
	<link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body id="top">
  
	<div class="main_wrapper parallax background-image" data-src="assets/img/youtube_video_bg.jpg" data-jarallax-video="mp4:./assets/video/videoplayback.mp4">
 
		  <!-- NAVBAR Start-->
		<?php include('include/header1.php');?>
		<!-- NAVBAR END-->

		<!-- LANDING CONTENT START -->
		<div class="landing_content">
			<div class="display_table">
				<div class="display_table_cell">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="landing_content">
									<h3>ONE OF INDIA’S LEADING</h3>
									<h2>Independent full-service Media  Specialists</h2>
									<p>TV, Online, Off Line Marketing & Event Management</p>
									<a class="onio_btn" href="about.php">View More</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- LANDING CONTENT END -->
	</div>
	<!-- MAIN END -->
	
	<!-- ABOUT START -->
	<div class="wrapper about_wrapper">
		<div class="container">
			<div class="row justify-content-center text-center">
				<div class="col-lg-6 col-md-9">
					<div class="about_header_text">
						<h1 class="primary_text">Our Vision Meets Your Reality</h1>
						<span class="secondary_text">Tell us your Vision & we’ll make you Achieve that.</span>
					</div>
				</div>
			</div>
			<div class="about_tiles text-center">
				<div class="row justify-content-center">
					<div class="col-md-4 col-lg-3">
						<h4 class="primary_text">Innovation</h4><br>
					  
					   <img src="assets/img/icon/1.png" alt="icon">
						<p class="pera_text">Our innovative approaches lead to High-level reach for your products, services and Business.</p>
					</div>
					<div class="col-md-4 col-lg-3 tiles_middle">
						<h4 class="primary_text">Advisory</h4><br>
					  
					   <img src="assets/img/icon/icon2.png" alt="icon">
						<p class="pera_text">Media strategy planning is our core strength. We provide end-to-end support for your Media Strategy roadmap planning & execution.</p>
					</div>
					<div class="col-md-4 col-lg-3">
						<h4 class="primary_text">Technology</h4><br>
					  
						 <img src="assets/img/icon/icon3.png" alt="icon">
						<p class="pera_text">We embrace technology to conduct the market research, media research and digital reach-out to the target audience.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="about_content">
				<div class="row align-items-center">
					<div class="col-md-6 mb30-sm">
						<h1 class="primary_text">Empirical Media</h1>
						<h4 class="secondary_text">Who are We?</h4>
						<p class="pera_text">The world’s leading media & entertainment companies understand that their success is driven by both art and science. With substantial usage of technology and digital media to be in par with the global industry standards, we achieve high index customer experience. We build trust by establishing our expertise in Market Assessment, Media Planning and Execution, Technologies, Cost & Effort optimization for our esteemed clients. We highly respect the value of data and analysis, conscious about working beyond trends. Our clients achieve revenue growth from the right audience and advertising. The time our clients and we spend assure a higher ROI.</p>
						<a class="onio_btn onio_btn_alt" href="about.php">Know More</a>
					</div>
					<div class="col-md-6">
						<!--  Overlay Image -->
						<div class="">
							<img class="img-fluid" src="assets/img/abt.jpg" alt="about">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- ABOUT  END -->
	<!-- SERVICE  START -->
	<div class="wrapper service_wrapper">
		<div class="container">
			<div class="row">
				<div class="col">
				   
					<div class="wrapper_heading_text">
						<h2 class="primary_text">Services</h2>
						 <h4 class="secondary_text">Build a Paradigm Shift to your Communication & Media Platform Strategy with Empirical Media!</h4>
					</div>
				</div>
			</div>
			<div class="row">

				<div class="col-lg-6 col-md-6">
					<div class="service_item">
						<div class="row">

							<div class="col-5 service_img background-image" data-src="assets/img/services/web.jpg"></div>
							<div class="col">
								<h2>TV, Digital & OTT Media</h2>
								<p class="pera_text">A solution that Integrates Traditional and Digital Media. Empirical Media understands you, your business and your end-users! The primary focus is to build a TV advertising, digital & OTT media strategy driven by data, analysis and in-depth market research. </p>
							</div>
						</div>
					</div>
				</div>

				<div class="col-lg-6 col-md-6">
					<div class="service_item">
						<div class="row">

							<div class="col-5 service_img background-image" data-src="assets/img/services/marketing.jpg"></div>
							<div class="col">
								<h2>Print Advertising, Radio, OOH & Transit and Cable</h2>
								<p class="pera_text">Our holistic approach takes you beyond TV advertising, Digital and OTT media buying and planning. Yes, we are the leading Media buying and planning partners in India for businesses across industries.</p>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
	<!-- SERVICE  END -->

	<!-- CONTACT US START -->
	<div class="wrapper hire_us_wrapper parallax">
		<div class="container">
			<div class="row align-items-center justify-content-center">
				<div class="col-md-12 text-center">
					<h2>Let's talk</h2>
					<h3>Stop By & Say "Hi", Or Drop Us A Note</h3>
					<a class="onio_btn" href="contact.php">Start Talk</a>
				</div>
			</div>
		</div>
	</div>
	<!-- CONTACT US END -->
 
	<!-- FAQ  START -->
	<div class="wrapper faq_wrapper">
		<div class="container">
			<div class="row">
				<div class="col">
				 
					<div class="wrapper_heading_text">
						<h2 class="primary_text">FAQ</h2>
						<h4 class="secondary_text">Easy-to-Understand.</h4>
					</div>
				</div>
			</div>
			<div class="row align-items-center">
				<div class="col-md-6">
					 <a href="assets/video/EM VIDEO 1.mp4" class="popup-youtube">
						<div class="faq_video">
							<img src="assets/img/play-icon.png" alt="icon">
						</div>
					</a>
				</div>
				<div class="col-md-6">
					<div class="accordion" id="accordionExample">
						<div class="card">
							<div class="card-header" id="headingOne">
								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Why is media planning important in advertising? <span class="icon-arrow-down"></span></button>
							</div>
							<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
								<div class="card-body">
									<span>Media planning that requires knowledge of both marketing and mass communication skills is the process of determining deals with the biggest portion of the advertiser's budget in terms of cost for buying placement of advertisement.</span>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="headingTwo">
								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">Would my business benefit from digital marketing? <span class="icon-arrow-right"></span></button>
							</div>
							<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
								<div class="card-body">
									<span>Definitely. Though companies in many business categories continue to approach digital marketing with skepticism, avoiding digital marketing denies your business access to the media the majority of consumers turn to first and at all hours of the day.</span>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="headingThree">
								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">How do I start this going with Empirical Media? <span class="icon-arrow-right"></span></button>
							</div>
							<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
								<div class="card-body">
									<span>You can reach us for a free consulting at Office hours on all working days. We will hand hold you and take you through the process to reach your Goals.</span>
								</div>
							</div>
						</div>
						<div class="card mb-0">
							<div class="card-header" id="headingFour">
								<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">Will it be too expensive? <span class="icon-arrow-right"></span></button>
							</div>
							<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
								<div class="card-body">
									<span>Not necessarily, It is absolutely based on the requirements of your Brand, product and Services. Its all ways better to understand, what your Brand's requirements are and then comparing the ROI. That will get the answer right.</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- FAQ  END -->

	<!-- TESTIMONIALS START -->
	<div class="wrapper testimonial_wrapper testimonial_wrapper_two">
		<div class="container">
			<div class="row">
				<div class="col">
	
					<div class="wrapper_heading_text">
						<h2 style="margin-bottom: 10px;" class="primary_text">Satisfied Clients</h2>
						 
					</div>
				</div>
			</div>
			<div class="row align-items-center brand_wrapper_two">
				<div class="col-md-5 order-md-first order-sm-last order-last">
					<div class="row no-gutters">
						<div class="col-md-6 col-sm-4 col-6">
							<img src="assets/img/brands/client1.jpg" alt="brand_01">
						</div>
						<div class="col-md-6 col-sm-4 col-6">
							<img src="assets/img/brands/client2.jpg" alt="brand_02">
						</div>
						<div class="col-md-6 col-sm-4 col-6">
							<img src="assets/img/brands/clinet3.jpg" alt="brand_03">
						</div>
						<div class="col-md-6 col-sm-4 col-6">
							<img src="assets/img/brands/client4.jpg" alt="brand_04">
						</div>
						<div class="col-md-6 col-sm-4 col-6">
							<img src="assets/img/brands/client5.jpg" alt="brand_05">
						</div>
						<div class="col-md-6 col-sm-4 col-6">
							<img src="assets/img/brands/client6.jpg" alt="brand_06">
						</div>
					</div>
				</div>
				<div class="col-md-7 order-md-last order-sm-first order-first mb30-sm">
					<div class="row">
						<div class="swiper-container testimonial">
							<div class="swiper-wrapper">
								
								<div class="col-12 single_testimonial swiper-slide">
									<div class="testimorial_img">
									  
									</div>
									<div class="testimorial_details">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris</p>
										<h3>Lorem ipsum</h3>
										<span>Lorem</span>
									</div>
								</div>
								<div class="col-12 single_testimonial swiper-slide">
									<div class="testimorial_img">
									 
									</div>
									<div class="testimorial_details">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris</p>
										<h3>Lorem ipsum</h3>
										<span>Lorem</span>
									</div>
								</div>
								<div class="col-12 single_testimonial swiper-slide">
									<div class="testimorial_img">
									   
									</div>
									<div class="testimorial_details">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris</p>
										<h3>Lorem ipsum</h3>
										<span>Lorem</span>
									</div>
								</div>
							</div>
							<!-- Testimonial Pagination -->
							<div class="swiper-pagination"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- TESTIMONIALS END -->
  
	<!-- FOOTER  START -->
		 <?php include('include/footer.php');?>
		  <a class="go_top" href="index.php#top"><i class="icon-arrow-up"></i></a>
	<!-- FOOTER  END -->


	<!-- jQuery JS-->
	<script src="assets/js/jquery.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Swiper JS -->
	<script src="assets/js/swiper.min.js"></script>
	<!-- Plugins JS -->
	<script src="assets/js/plugins.js"></script>
	<!-- Main JS -->
	<script src="assets/js/main.js"></script>
</body>

</html>
