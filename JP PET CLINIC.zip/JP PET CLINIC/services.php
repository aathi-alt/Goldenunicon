<!DOCTYPE html>
<html lang="en">
<head>
<title>JP Pet Clinic</title>
	<meta name="Description" content="" />
  <meta name="Keywords" content="" />		
	<?php include 'includes/csslinks.php';?>
</head>
<body class="servicesPage">
<!--header-->
<?php include 'includes/header.php';?>
<!--/header-->
<div class="about">
	<div class="container">
		<div class="about-top">
			<div class="about-top-info">
				<h3>Services</h3>


				<div class="col-md-4 about-img">
					<img src="images/pic10.jpg" alt=""/>
				</div>
				<div class="col-md-8 about-desc">
					<h4>PET HEALTH CARE</h4>
					<p>We perform a thorough physical examination to determine the Pet’s state of health.  We provide the best medical and surgical care to resolve a variety of pet-related medical problems.</p>
					<ul>
						<li>General Health Check-up</li>
						<li>Internal Medicine</li>
						<li>Vaccination & De-worming</li>
						<li>General Surgery</li>
						<li>Gynecology & Obstetrics</li>
						<li>Dermatology</li>
						<li>Ophthalmology</li>
						<li>Orthopedics</li>
						<li>Dentistry</li>
						<li>Diagnostic Imaging</li>
						<li>Cardiology</li>
						<li>Neonatology</li>
					</ul>
				</div>
				<div class="clearfix mb50"> </div>

				<div class="col-md-4 about-img pull-right">
					<img src="images/specialized-facilities.jpg" alt=""/>
				</div>
				<div class="col-md-8 about-desc">
					<h4>Specialized Facilities </h4>
					<p>The team at JP Pet Speciality Hospital are very dedicated and experienced who have converted their love of animals into a professional choice. Under Dr.JP’s expert guidance, we are emerging as THE place to go for all of your pet’s grooming and personal care needs.</p>
					<p>Our Services include, but are not limited to: Ultrasound,X-Ray, On-Screen Exam, Microchip Implant, Soft Tissue & Orthopedic Surgery, In-Clinic FIV Test, Laser for Surgery & Therapy,Electrocardiogram,Ophthalmic Surgery ,Complete Blood Test.</p>
					<ul>
						<li>Computed Radiography</li>
						<li>Doppler Ultrasound</li>
						<li>Echo-cardiography</li>
						<li>X-Ray</li>
						<li>Blood Tests</li>
					</ul>
				</div>
				<div class="clearfix mb50"> </div>

				<div class="col-md-4 about-img">
					<img src="images/operation-theater.jpg" alt=""/>
				</div>
				<div class="col-md-8 about-desc">
					<h4>Equiped Operation Theater</h4>
					<p>The fully equiped operation theater with Gas Anaesthesia Machine, Vital Signs Monitors, Ventilators, Electronic Vessel Sealer, Ultrasound Digital Scanner, Infusion Pump online oxygen, Specialized Instrument for Orthopedic, Ophthalmologic, Thyrocare and Shift Home services. JP Pets specialty hospital is fully equipped and capable to perform all specialty surgical procedures.</p>
				</div>
				<div class="clearfix mb50"> </div>

				<div class="col-md-4 about-img pull-right">
					<img src="images/pet-spa.jpg" alt=""/>
				</div>
				<div class="col-md-8 about-desc">
					<h4>PET SPA / Grooming and Bathing</h4>
					<p>Pet grooming is not easy if you are not aware of your companion animal’s nature, likes and dislikes. Certain tasks, which seem simple and fun to you, might not appeal to your furry friend. This is when you need assistance of a professional groomer. At V-care Pet Clinic we make every grooming session as much enjoyable as possible for both the owner and the pet. We promise that your adorable pet would remember this one grooming session and would love to come back to us for the next.</p>
					<p>Apart from regular grooming we offer specialized services like deep coat conditioning, salon style nail trimming followed by polishing, full body clip, teeth brushing, shaving footpads, sanitary clip and more</p>
					<ul>
						<li>Medicated Grooming</li>
						<li>Full Shave grooming for skin infected Pets</li>
						<li>Application of medicated shampoos and bathing  </li>
						<li>Nail clipping, Ear cleaning</li>
						<li>Professional/Show Grooming</li>
					</ul>
				</div>
				<div class="clearfix mb50"> </div>

				<div class="col-md-4 about-img">
					<img src="images/pet-shelter.jpg" alt=""/>
				</div>
				<div class="col-md-8 about-desc">
					<h4>PET Holiday Home</h4>
					<p>It's fun and safe; there’s room to run around, lots of human attention and plenty of canine companionship. Our pet shelter is available everyday, Dogs are placed into shelters according to size.</p>
				</div>
				<div class="clearfix mb50"> </div>


				<div class="col-md-4 about-img pull-right">
					<img src="images/pet-shop.jpg" alt=""/>
				</div>
				<div class="col-md-8 about-desc">
					<h4>Pet Shop</h4>
					<p>We have been serving the animals of Chennai, Coimbatore and beyond for almost 25 years. We carry only the highest quality pet foods with a special focus on raw/frozen foods. We are committed to helping owners find a diet that best suits their pet's needs.</p>
					<p>We have a wide selection of unique toys, collars, leashes, outdoor gear, sweaters, coats, grooming products, supplements and training aids.</p>
				</div>
			</div>
		</div>

	<div class="clearfix"> </div>
	</div>
</div>
<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
	</body>
</html>
