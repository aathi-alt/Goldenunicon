String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}
function limitText(limitField, limitCount, limitNum) {
	
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}
function noempty()
{
	var desc = document.getElementById("Description").value;
	var fname = document.getElementById("S_name").value;
	var semail  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var em = document.getElementById("S_email").value;
	var ct = document.getElementById("country").value;
	var tel = document.getElementById("S_phone").value;
	var mob = document.getElementById("S_mobile").value;
	var vc = document.getElementById("verify_code").value;
	var bad_words_array=new Array("href", "xxx", "viagra", "porn", "sex");
	if(desc.trim() == "" || desc == "Description")
	{
		alert("Please Enter Description");
		document.getElementById("Description").value ="";
		document.getElementById("Description").focus();
		return false;
	}
	else
		bwords=badwords(desc);
	
	if(bwords>0)
	{
		alert("Your message contains inappropriate words. Please re-type your Enquiry/Requirements.");
		document.getElementById("Description").value = "";
		document.getElementById("Description").focus();
		return false;
	}
	if(fname.trim()=="" || fname=="First Name")
	{
		alert("Please Enter First Name");
		document.getElementById("S_name").value = "";
		document.getElementById("S_name").focus();
		return false;
	}
	if(em.trim() == "")
	{
		alert("Please Enter Email");	
		document.getElementById("S_email").value = "";
		document.getElementById("S_email").focus();
		return false;
	}
	if(!em.match(semail))
	{
		alert("Please Enter Valid Email");
		document.getElementById("S_email").value="";
		document.getElementById("S_email").focus();
		return false;
	}
	if(ct == 0)
	{
		alert("Please Select Country");
		document.getElementById("country").focus();
		return false;
	}
	var acode = document.getElementById("S_phone_area_code").value;
	
	if(!parseFloat(acode) && acode!="" && acode!="Area Code")
	{
		alert("Please Enter Telephone Area Code in Numbers");
		document.getElementById("S_phone_area_code").value = "";
		return false;
	}
	if(tel.trim() == "" || tel == "Phone Number")
	{
		if(mob.trim() == "" || mob == "Mobile / Cell Phone Number" || mob.length < 10)
		{
			alert("Please Enter Telephone / 10 Digit Mobile Number");
			document.getElementById("S_phone").value = "";
			document.getElementById("S_mobile").value = "";
			return false;
		}
	}
	if(tel!="" && tel != "Phone Number")
	{
		if(!parseInt(tel))
		{
			alert("Please Enter Telephone in Numbers");
			document.getElementById("S_phone").value = "";
			document.getElementById("S_phone").focus();
			return false;
		}
	}
	
	if(tel!="" && tel!="Phone Number" )
	{
		var acode = document.getElementById("S_phone_area_code").value;
		if(acode=="" || acode=="Area Code")
		{
			alert("Please Enter Area Code");
			document.getElementById("S_phone_area_code").value = "";
			document.getElementById("S_phone_area_code").focus();
			return false;
		}
	}
	if(mob!="" && mob!="Mobile / Cell Phone Number")
	if(!parseInt(mob))
	{
		alert("Please Enter Mobile in Numbers");
		document.getElementById("S_mobile").value = "";
		return false;
	}
	if(vc.trim() == "" || vc == "Code")
	{
		alert("Please Enter Verification Code");	
		document.getElementById("verify_code").value = "";
		document.getElementById("verify_code").focus();
		return false;
	}
	var ocaptcha = document.getElementById("hide_captcha_code").value;
	   // ocaptcha = $.base64.decode(ocaptcha);
	if(vc!="" && vc!=ocaptcha)
	{
		alert("Please Correct Verification Code");	
		document.getElementById("verify_code").value = "";
		document.getElementById("verify_code").focus();
		return false;
	}
	function badwords(txt)
	{
		var alert_arr=new Array;
		var alert_count=0;
		var compare_text=txt;
		
		for(var i=0; i<bad_words_array.length; i++)
		{
			for(var j=0; j<(compare_text.length); j++)
			{
				if(bad_words_array[i]==compare_text.substring(j,(j+bad_words_array[i].length)).toLowerCase())
				{
				  alert_count++;
				}
			}
		}
		return alert_count;
	}
    $('input[type="submit"]').attr('disabled', true);
    $('input[type="submit"]').val('Please Wait');
}
function isNumberKey(evt)
{
 var charCode = (evt.which) ? evt.which : event.keyCode
 if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;

 return true;
}
