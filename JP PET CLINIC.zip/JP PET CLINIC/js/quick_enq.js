String.prototype.trim = function() {
return this.replace(/^\s+|\s+$/g,"");
}
function quick_noempty()
{
	var semail  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var sname =  /^[a-zA-Z ]*$/;
	var name = document.getElementById("quick_name").value;
	var em = document.getElementById("quick_email").value;
	var location = document.getElementById("quick_location").value;
	var phone = document.getElementById("quick_phone").value;
	var desc = document.getElementById("quick_desc").value;
    var vc = document.getElementById("quick_verify_code").value;   
    //var category = document.getElementById("category").value;
	//var bad_words_array=new Array("href", "xxx", "viagra", "porn", "sex");
	
	if(name.trim()=="" || name == "Name")
	{
		alert("Please Enter Name");
		document.getElementById("quick_name").value="";
		document.getElementById("quick_name").focus();
		return false;
	}
	if(!name.match(sname))
	{
		alert("Please Enter Valid Name (Only Alphabets)");
		document.getElementById("quick_name").value="";
		document.getElementById("quick_name").focus();
		return false;
	}
	if(em.trim() == "")
	{
		alert("Please Enter Email");	
		document.getElementById("quick_email").value = "";
		document.getElementById("quick_email").focus();
		return false;
	}
	if(!em.match(semail))
	{
		alert("Please Enter Valid Email");
		document.getElementById("quick_email").value="";
		document.getElementById("quick_email").focus();
		return false;
	}
	if(phone.trim() == "" || phone == "Phone" || (phone.length < 10))
	{
		alert("Please Enter 10 Digit Phone Number");
		document.getElementById("quick_phone").value="";
		document.getElementById("quick_phone").focus();
		return false;
	}
	if(!parseInt(phone))
	{
		alert("Please Enter Phone in Numbers");
		document.getElementById("quick_phone").value = "";
		return false;
	}
	if(location.trim()=="" || location == "Location")
	{
		alert("Please Enter Location");
		document.getElementById("quick_location").value="";
		document.getElementById("quick_location").focus();
		return false;
	}
	if(desc.trim() == "" || desc == "Enter your requirement in detail")
	{
		alert("Please Enter Description");
		document.getElementById("quick_desc").value ="";
		document.getElementById("quick_desc").focus();
		return false;
	}
	if(vc.trim() == "" || vc == "Code")
	{
		alert("Please Enter Verification Code");	
		document.getElementById("quick_verify_code").value = "";
		document.getElementById("quick_verify_code").focus();
		return false;
	}
	/*if($('#category').css('display') != 'none'){
		if(category.trim()=="")
		{
			alert("Please Select Category");
			document.getElementById("category").value="";
			document.getElementById("category").focus();
			return false;
		}
	}*/
	var ocaptcha = document.getElementById("quick_hide_captcha_code").value;
              //ocaptcha = $.base64.decode(ocaptcha);
	if(vc!="" && vc!=ocaptcha)
	{
		alert("Please Correct Verification Code");	
		document.getElementById("quick_verify_code").value = "";
		document.getElementById("quick_verify_code").focus();
		return false;
	}
	$('#quick_btnsubmit').attr('disabled', true);
    $('#quick_btnsubmit').val('Please Wait');
}
function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;

 	return true;
}
