<!DOCTYPE html>
<html lang="en">
<head>

<title>JP Pet Clinic</title>
<meta name="Description" content="" />
<meta name="Keywords" content="" />		
<?php include 'includes/csslinks.php';?>

</head>
<body class="homePage">
<!--header-->

<?php include 'includes/header.php';?>

<div class="header-banner">
	<div class="slider">
	  <ul class="rslides" id="slider2">
	    <li><a href="#"><img src="images/1.jpg" class="img-responsive" alt=""/></a></li>
	    <li><a href="#"><img src="images/2.jpg" class="img-responsive" alt=""/></a></li>
	    <li><a href="#"><img src="images/4.jpg" class="img-responsive" alt=""/></a></li>
	    <li><a href="#"><img src="images/5.jpg" class="img-responsive" alt=""/></a></li>
	  </ul>
	</div>
</div>
<!--/header-->
<!--doctor-self-->
<div class="doctor-self">
	<div class="container">
		<div class="doctor-self-info">
			<h3>WHAT OUR DOCTOR SAYS</h3>
			<div class="doctor-self-info-bottom">
				<div class="col-md-4 doctor-self-left">
					<img src="images/A.jpg" class="img-responsive" alt=""/>
					<h4>Prof. Dr. R. Jayaprakash, MVSC, Phd.</h4>
					<h5>Chief Doctor & Founder of JP Pet Speciality Hospital in the year 1988 in Chennai.</h5>
				</div>
				<div class="col-md-8 doctor-self-right">
					<p>When you are looking for a complete pet care hospital with dedicated, experienced services, excellent state of the art facility and superior treatment, JP Pet specialty hospital provides all your pet's needs beyond your expectation. Prof. Dr. R. Jayaprakash, MVSC, Phd who has 30 years of hands on rich experience in pet care. He is the chief consultant, under his able guidance the team of highly qualified experienced doctors from different pet's specialty. The team serves with dedication, concern and compassion towards pets and their well being.</p> 
					<p>JP Pet specialty hospital is fully functional with high end Diagnostic facility and full fledged operation theater. The Diagnostic facility includes but not limited to Computed Radiography, Colour Doppler / Ultrasound, ECG, Doppler BP recorders and complete inhouse laboratory with auto analyzers. JP Pet Specialty hospital provides instant diagnostic results for effective treatment.</p>
					<p>The fully equiped operation theater with Gas Anaesthesia Machine, Vital Signs Monitors, Ventilators, Electronic Vessel Sealer, Ultrasound Digital Scanner, Infusion Pump online oxygen, Specialized Instrument for Orthopedic, Ophthalmologic, Thyrocare and Shift Home services. JP Pets specialty hospital is fully equipped and capable to perform all specialty surgical procedures.</p>
					<p>Pet Comfort Felicity, Pet Pharmacy, Pet Shop, Pet Spa, Pet Holiday Home, Pet Swimming Pool, Pet Taxi are other services provided by JP Pet Specialty Hospital that gives your pet a complete care and need.</p>
				</div>
				<div class="clearfix"> </div>
				</div>
		</div>
	</div>
</div>
<!--/doctor-self-->
<!--dogs-food-->
<div class="dogs-food">
	<div class="container">
		<div class="dogs-food-top-info">
		<div class="dogs-food-top">
			<div class="col-md-4 dogs-food-info">
				<img src="images/dg-1.png">
				<h4>PET HEALTH CARE</h4>
				<p>We perform a thorough physical examination to determine the Pet’s state of health...</p>
					 <a class="dogs-top-food" href="services.php">More</a>
			</div>
			<div class="col-md-4 dogs-food-info">
				<img src="images/dg-2.png">
				<h4>Specialized Facilities</h4>
				<p>Our Services include, but are not limited to: Ultrasound,X-Ray, On-Screen Exam,...</p>
					<a class="dogs-top-food" href="services.php">More</a>
			</div>
			<div class="col-md-4 dogs-food-info">
				<img src="images/dg-3.png">
				<h4>Equiped Operation Theater</h4>
				<p>The team at JP Pet Speciality Hospital are very dedicated and experienced who have...</p>
					<a class="dogs-top-food" href="services.php">More</a>
			</div>
			<div class="col-md-4 dogs-food-info">
				<img src="images/dg-4.png">
				<h4>Pet Spa / Grooming and Bathing</h4>
				<p>Our pet spa is a leader in the pet spa industry. After many years of experience...</p>
				<a class="dogs-top-food" href="services.php">More</a>
			</div>
				<div class="col-md-4 dogs-food-info">
					<img src="images/dg-5.png">
					<h4>Pet Holiday Home</h4>
					<p>It's fun and safe; there’s room to run around, lots of human attention and plenty...</p>
						<a class="dogs-top-food" href="services.php">More</a>
				</div>
				<div class="col-md-4 dogs-food-info">
					<img src="images/dg-6.png">
					<h4>Pet Shop</h4>
					<p>We have been serving the animals of Chennai, Coimbatore and beyond for almost 25 years...</p>
						<a class="dogs-top-food" href="services.php">More</a>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!--/dogs-food-->

<!--support-->
<div class="support">
	<div class="container">
		<div class="support-info">
			<h4>OUR TEAM FOR SUPPORT</h4>
			
			<div class="clearfix"> </div>
			<div class="tm-head-grids" >
				<div class="tm-head-grid" >
					<img src="images/team-member1.jpg" alt="" />
					<h4>Dr. R. Jayaprakash, MVSC, Phd.</h4>
					<h5></h5>
				</div>
				<div class="tm-head-grid">
					<img src="images/team-member2.jpg" alt="" />
					<h4>Dr. J. Arun Pari.</h4>
					<h5></h5>
				</div>
				<div class="tm-head-grid" style="display:none;">
					<img src="images/team-member3.jpg" alt="" />
					<h4>Dr. G. Venugobal.</h4>
					<h5></h5>
				</div>
				<div class="tm-head-grid">
					<img src="images/team-member4.jpg" alt="" />
					<h4>Er. JN. Lenin Siddharth.</h4>
					<h5></h5>
				</div>				
			</div>
			<div class="clearfix"> </div>
			<div class="support-info-left">
				<div class="col-md-12 support-info-left-bottom">
					<p>Our team is committed to educating our clients in how to keep your pets healthy year round, with good nutrition and exercise.  JP Pet Specialty hospital Staff stays on top of the latest advances in veterinarian technology and above all, remembers that all animals and pets need to be treated with loving care in every check-up, procedure, or surgery. </p>
				</div>
				<!-- <div class="col-md-2 support-info-left-top">
					<img src="images/support.png" class="img-responsive" alt=""/>
				</div> -->
			</div>		
		</div>
	</div>
</div>
	<div class="home-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.548507265786!2d80.25023731482224!3d13.000703990836843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a526796c5555555%3A0xf3259e6901307f85!2sJP+Pet+Clinic!5e0!3m2!1sen!2sin!4v1512373571548" ></iframe>
	</div>
<!--/support-->
<!--contact-->
<div class="contact">
	<div class="container">
		<div class="contact-info">
			<h4>CONTACT-US</h4>
			<!-- <p></p> -->
		</div>
		
		<div class="clearfix">
			<form action="post-enquiry.php" method="post" class="frm_mini" onSubmit="return quick_noempty();">
		    <div class="mini_width_left">
		      <input type="text" name="name" id="quick_name" placeholder="NAME"/>      
		      <input type="text" name="email" id="quick_email" onblur="quickcheckEmail(this.value);" placeholder="EMAIL" />
		    </div>
		    <div class="mini_width_right">
		      <input type="text" name="phone" id="quick_phone" onKeyPress="return isNumberKey(event);"  placeholder="PHONE" />
		      <input type="text" name="location" id="quick_location" placeholder="LOCATION" />    
		    </div>
				<div class="mini_width_top">
	        <textarea name="desc" id="quick_desc" rows="20" style="height:120px;" placeholder="MESSAGE"></textarea>
		    </div>
		    <div class="clear"></div>
		    <div class="mini_width_bottom">				    	
	        <?php $code = rand(100, 999); ?>
	        <img  draggable="false" src="http://www.goldenunicon.com/CaptchaSecurityImages.php?security=<?php echo base64_encode($code);?>" class="cptcha-img" style="float:left" alt="captcha image"/>
	        <input type="hidden" name="original_captcha" readonly  id="quick_original_captcha" value="<?php echo base64_encode($code);?>" />
	        <input type="hidden" name="hide_captcha_code" id="quick_hide_captcha_code" readonly  value="<?php echo $code;?>" />
	        <input name="captcha_text" type="text" id="quick_verify_code" class="captcha-text"  Placeholder="Code" maxlength="3" onKeyPress="return isNumberKey(event);"/> 
		      <input name="quick_btnsubmit" id="" class="submitBtn" type="hidden" value="SUBMIT" />
		      <input name="" id="quick_btnsubmit" class="submitBtn" type="submit" value="SUBMIT" />
		      <div class="clear"></div>
		    </div>
		  </form>
		  <script src="http://www.goldenunicon.com/js/jquery.js" type="text/javascript"></script>
			<script type="text/javascript" src="http://www.goldenunicon.com/js/base64.js"></script>
			<script type="text/javascript" src="http://www.goldenunicon.com/js/quick_enq.js"></script>
		</div>

	</div>
</div>
<!--/contact-->
<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
</body>
</html>
