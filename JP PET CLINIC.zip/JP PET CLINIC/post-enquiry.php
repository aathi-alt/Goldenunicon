<?php
require '/home/ubuntu/vendor/autoload.php';
 if(isset($_POST['quick_btnsubmit'])){
  error_reporting(0);
  include("./includes/class.phpmailer.php");
  $name         = $_POST['name'];
  $email        = $_POST['email'];
  $mobile       = $_POST['phone'];
  $location     = $_POST['address'];
  $decs         = $_POST['desc'];
  $contact_name ="Please check the Requirement";
  $message = "";
  $subject_thankyou = "Enquiry Acknowledgement from JP Pet Specialty Hospital.";
  $message_thankyou = "<p>Dear ".$name.",</p><p>We just received your enquiry. We will get back to you as soon as possible. Thank you for the interest shown on JP Pet Specialty Hospital.</p><p>Best Regards<br />JP Pet Specialty Hospital<br/> Web :<a href='http://www.goldenunicon.com/'>www.goldenunicon.com</a></p>";
  $mail = new PHPMailer;
  $mail->IsSMTP(); // enable SMTP
  $mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
  $mail->SMTPAuth  = true;  // authentication enabled
  $mail->SMTPSecure = 'ssl';
  $mail->Host     = "email-smtp.eu-west-1.amazonaws.com";/*Specify main and backup SMTP servers*/
  $mail->Port     = 465;
  $mail->SMTPAuth = true;/*Enable SMTP authentication*/
  $mail->Username = "AKIAI3JE6BWII7K53W7Q";/*SMTP username*/
  $mail->Password = "AhRDX1+I/wxdoDBSW/J87xRuMj/xtBATtfv71P+MKbPD";/*SMTP password*/

  $mail->setFrom('emailer@goldenunicon.in', 'JP Pet Specialty Hospital');
  $mail->addAddress($email , $name);
  $mail->isHTML(true);

  $mail->Subject = $subject_thankyou;
  $mail->Body    = $message_thankyou;
  $mail->AltBody = $subject_thankyou;
  $mail->send();
  $subject ='Enquiry for JP Pet Specialty Hospital'; 
  $email_header ='<html style="color: rgb(34, 34, 34); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: -webkit-auto; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); max-width: 575px; line-height: 18px; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">
                    <head>
                      <meta name="viewport" content="width=device-width" />
                      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
                  </head>
                  <body bgcolor="#FFFFFF" text="#000000"  style="color: rgb(34, 34, 34); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: 2; text-align: -webkit-auto; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); max-width: 575px; line-height: 18px; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">
                  <table style="font-family:Helvetica,Arial,sans-serif;background:#EFEDED;padding:0 0 10px 0;" cellpadding="0" cellspacing="0" bgcolor="#EFEDED" border="0" width="100%">
                  <tbody>
                  <tr>
                  <td align="center">
                  <table width="96%" cellpadding="0" cellspacing="0"border="0">
                  <tbody>              
                  <tr>
                  <td style="border-top:5px solid #1e96d3;background:#fff;margin:0; padding:20px; border-spacing:0px;">';
  $email_footer = '</td>
                    </tr>               
                    </tbody>
                    </table>
                    </td>
                    </tr>
                    </tbody>
                    </table>
                    </td>
                    </tr>              
                    </tbody>
                    </table>
                    </body>
                    </html>';
    $body = $email_header.
        '<table width="100%" cellpadding="0" cellspacing="0">
              <tr>
              <td style="margin:0; padding:0px 0px 15px 0px; border-spacing:0px;">
              <p style="font-size:14px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: bold; line-height: 1.5em; margin: 0px; padding: 0.4em; text-align: left;">
              '.$subject.'
              </p>
              </td>
              </tr>
              <tr>
              <td style="margin:0; padding:0px 0px 15px 0px; border-spacing:0px;">
              <p style="color:#000; font-size:13px; margin:0; font-family:Arial, Helvetica,sans-serif;">
              <strong>
              '.$contact_name.',
              </strong>
              <br>
              </p>
              </td>
              </tr>                     
              <tr>
              <td style="margin:0; padding:0 0 5px 0;">
              <p style="font-size:13px; background-color: rgb(234, 234, 234); color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-weight: bold; line-height: 1.5em; margin: 0px; padding: 0.4em; text-align: left;">
              Details:
              </p>
              </td>
              </tr>
              <tr>
              <td style="margin:0; padding:0px 0px 15px 0px; border-spacing:0px;">
              <table style="font-family:Helvetica,Arial,sans-serif; font-size:12px; font-weight:bold; margin-top:10px; width:100%">
              <tbody>
              <tr>
              <td style="width:120px; padding:4px 0;">
              Name
              </td>  
              <td style="padding-right:10px;">
              :
              </td>
              <td style="font-weight:normal;">
              '.$name.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
              Phone Number
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$mobile.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
              Email
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$email.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
              Location
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$location.'
              </td>
              </tr>
              <tr>
              <td style="padding:4px 0;">
              Description
              </td>
              <td>
              :
              </td>
              <td style="font-weight:normal;">
              '.$decs.'
              </td>
              </tr>
              </tbody>
              </table>
              </td>
              </tr>
              </table>'
              .$email_footer;
              //print_r($body);die;
    $message .= $body;
    $mail = new PHPMailer;
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
    $mail->SMTPAuth  = true;  // authentication enabled
    $mail->SMTPSecure = 'ssl';
    $mail->Host     = "email-smtp.eu-west-1.amazonaws.com";/*Specify main and backup SMTP servers*/
    $mail->Port     = 465;
    $mail->SMTPAuth = true;/*Enable SMTP authentication*/
    $mail->Username = "AKIAI3JE6BWII7K53W7Q";/*SMTP username*/
    $mail->Password = "AhRDX1+I/wxdoDBSW/J87xRuMj/xtBATtfv71P+MKbPD";/*SMTP password*/
    $mail->setFrom('emailer@goldenunicon.in', $name);
    $mail->addAddress('arul132@gmail.com' , 'Enquiry');
    // $mail->addCC('');
    $mail->addBCC('cmail@goldenunicon.in'); 
    // $mail->addBCC('sunil@floretmedia.org');
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = $subject;
    // $mail->send();
  if(!$mail->send()) {
    ?>
    <script type="text/javascript">
       window.alert("mail not sent successfully!");
     // window.top.location.href="thanks.php";
    </script>
    <?php
  }
  else{
     header("location:thanks.php");
  }
}
?>

