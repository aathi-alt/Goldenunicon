<div class="headerFixed">
	<div class="header">
		<div class="header-info">
		  <div class="container">
			<div class="logo">
					<a href="./"><img src="images/logo.png" alt="" /></a><!-- <h1>JP Pet <br/><span>Speciality Hospital</span></h1> -->
			</div>
		    <div class="clearfix"> </div>
		  </div>
		</div>
	</div>


	<div class="container">
		<div class="header-bottom">
			<div class="menu">
				<span class="menu-info"></span>
				<ul class="cl-effect-21">
					<li><a class="mhm" href="./">HOME</a></li>
					<li><a class="mabt" href="about.php">ABOUT</a></li>
					<li><a class="mser" href="services.php">SERVICES</a></li>
					<li><a class="mfac" href="facilities.php">FACILITIES</a></li>
					<li><a class="mcarp" href="careplus.php">CAREPLUS</a></li>
					<li><a class="mcnt" href="contact.php">CONTACT</a></li>
				</ul>
			</div>
		<div class="clearfix"> </div>	
		</div>
	</div>
</div>