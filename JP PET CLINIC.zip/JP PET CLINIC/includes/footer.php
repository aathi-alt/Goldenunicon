<div class="footer">
	<div class="container">
		<p class="cprt">&copy;<?php echo date("Y"); ?> JP Pet Clinic. All Rights Reserved.</p>
  	<a class="pwdBy" target="_blank" href="http://www.goldenunicon.com/">Powered by Golden Unicon LLP</a>		
	</div>
</div>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script>
// You can also use "$(window).load(function() {"
$(function () {
  $("#slider2").responsiveSlides({
    auto: true,
    pager: true,
    speed: 300,
    namespace: "callbacks",
  });
});

var previousScroll = 50;
$(window).scroll(function(){
  var currentScroll = $(this).scrollTop();
  if (currentScroll > previousScroll){
    $(".headerFixed").addClass("sticky");
  } else {
    $(".headerFixed").removeClass("sticky");
  }
});
</script>

<!--script-nav -->	
<script>
$("span.menu-info").click(function(){
$("ul.cl-effect-21").slideToggle("slow" , function(){
});
});
</script>
<!-- /script-nav -->