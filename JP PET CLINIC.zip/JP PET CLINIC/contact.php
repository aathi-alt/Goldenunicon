<!DOCTYPE html>
<html lang="en">
<head>
<title>JP Pet Clinic</title>
	<meta name="Description" content="" />
  <meta name="Keywords" content="" />		
	<?php include 'includes/csslinks.php';?>
</head>
<body class="contactPage">
<!--header-->
<?php include 'includes/header.php';?>
<!--/header-->
<div class="contact_top">
	<div class="container">
	<h4>Contact</h4>
		<div class="maps">
			<div class="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.548507265786!2d80.25023731482224!3d13.000703990836843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a526796c5555555%3A0xf3259e6901307f85!2sJP+Pet+Clinic!5e0!3m2!1sen!2sin!4v1512373571548" style="border: none;"></iframe>
			</div>
		</div>
					<div class="contact-us-down">
								<div class="col-md-6 contact-left">
									<h5>CONTACT-INFO</h5>
										
						 			<address>
										<strong>JP PET SPECIALITY HOSPITAL.<br>
										Kasthuribai Nagar,<br>
										Adyar, Chennai</strong><br>
										Telephone: +91 044-24411909,43522909, +91 994 451 4417<br>
										E-mail: <a href="mailto:info@jppethospital.com">info@jppethospital.com</a><br>
									</address>

									<address>
										<strong>JP PET SPECIALITY HOSPITAL.<br>
										No 136, 2nd Avenue, 8th Cross Street Kuthbi Complex, <br/>Vettuvankeni, Chennai - 600115, <br/>Opp to Bashera Hotel,<br/>Backside of Border Parota</strong><br>
										Telephone: +91 755 003 4909<br>
										E-mail: <a href="mailto:info@jppethospital.com">info@jppethospital.com</a><br>
									</address>

									<address>
										<strong>JP PET SPECIALITY HOSPITAL.<br>
										122, Venkata Krishna Rd, R.S. Puram, <br/>Coimbatore, Tamil Nadu 641002</strong><br>
										Telephone: +91 0422 435 7755, +91 915 238 5794<br>
										E-mail: <a href="mailto:info@jppethospital.com">info@jppethospital.com</a><br>
									</address>


                </div>
								<div class="col-md-6 contact-us-info">							
									<h5>ENQUIRY</h5>
									<div class="clearfix">
										<form action="post-enquiry.php" method="post" class="frm_mini" onSubmit="return quick_noempty();">
									    <div class="mini_width_left">
									      <input type="text" name="name" id="quick_name" placeholder="NAME"/>      
									      <input type="text" name="email" id="quick_email" onblur="quickcheckEmail(this.value);" placeholder="EMAIL" />
									    </div>
									    <div class="mini_width_right">
									      <input type="text" name="phone" id="quick_phone" onKeyPress="return isNumberKey(event);"  placeholder="PHONE" />
									      <input type="text" name="location" id="quick_location" placeholder="LOCATION" />    
									    </div>
											<div class="mini_width_top">
								        <textarea name="desc" id="quick_desc" rows="20" style="height:120px;" placeholder="MESSAGE"></textarea>
									    </div>
									    <div class="clear"></div>
									    <div class="mini_width_bottom">				    	
								        <?php $code = rand(100, 999); ?>
								        <img  draggable="false" src="http://www.goldenunicon.com/CaptchaSecurityImages.php?security=<?php echo base64_encode($code);?>" class="cptcha-img" style="float:left" alt="captcha image"/>
								        <input type="hidden" name="original_captcha" readonly  id="quick_original_captcha" value="<?php echo base64_encode($code);?>" />
								        <input type="hidden" name="hide_captcha_code" id="quick_hide_captcha_code" readonly  value="<?php echo $code;?>" />
								        <input name="captcha_text" type="text" id="quick_verify_code" class="captcha-text"  Placeholder="Code" maxlength="3" onKeyPress="return isNumberKey(event);"/> 
									      <input name="quick_btnsubmit" id="" class="submitBtn" type="hidden" value="SEND" />
									      <input name="" id="quick_btnsubmit" class="submitBtn" type="submit" value="SEND" />
									      <div class="clear"></div>
									    </div>
									  </form>
									  <script src="http://www.goldenunicon.com/js/jquery.js" type="text/javascript"></script>
										<script type="text/javascript" src="http://www.goldenunicon.com/js/base64.js"></script>
										<script type="text/javascript" src="http://www.goldenunicon.com/js/quick_enq.js"></script>
									</div>


								</div>
								<div class="clearfix"> </div>
					</div>
        </div>	
  </div>	
<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
</body>
</html>
