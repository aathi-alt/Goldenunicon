<!DOCTYPE html>
<html lang="en">
<head>
<title>JP Pet Clinic</title>
	<meta name="Description" content="" />
  <meta name="Keywords" content="" />		
	<?php include 'includes/csslinks.php';?>
</head>
<body class="facilitiesPage">
<!--header-->
<?php include 'includes/header.php';?>
<!--/header-->
<div class="support_top">
	<div class="container">
		<h4>Facilities</h4>
			<div class="support-info">
				<div class="col-md-4 support-info-top">
					<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
				</div>
				<div class="col-md-8 support-info-bottom">
					<img src="images/dog-fight.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="clearfix"> </div>
			</div>
	 </div>
</div>



<div class="support-bottom">
	<div class="container">
		<div class="col-md-4 support-bottom-top">
			<img src="images/c1.jpg" />
			<div class="grid-bottom">
				<h3>Pet Shelter</h3>						
			</div>
		</div>
		<div class="col-md-4 support-bottom-top">
			<img src="images/c2.jpg" />
			<div class="grid-bottom">
				<h3>Pet Pharmacy and Store</h3>
			</div>
		</div>
		<div class="col-md-4 support-bottom-top">
			<img src="images/c3.jpg" />
			<div class="grid-bottom">
				<h3>Pet Store</h3>
			</div>
		</div>
		<div class="clearfix mb50"> </div>
		<div class="col-md-4 support-bottom-top">
			<img src="images/c4.jpg" />
			<div class="grid-bottom">
				<h3>Waiting Room 1</h3>
			</div>
		</div>
		<div class="col-md-4 support-bottom-top">
			<img src="images/c5.jpg" />
			<div class="grid-bottom">
				<h3>Waiting Room 2</h3>
			</div>
		</div>
		<div class="col-md-4 support-bottom-top">
			<img src="images/c6.jpg" />
			<div class="grid-bottom">
				<h3>Consulting Room</h3>
			</div>
		</div>
	</div>
</div>




<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
	</body>
</html>
