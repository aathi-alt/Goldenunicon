<!DOCTYPE html>
<html lang="en">
<head>
<title>JP Pet Clinic</title>
	<meta name="Description" content="" />
  <meta name="Keywords" content="" />		
	<?php include 'includes/csslinks.php';?>
</head>
<body>
<!--header-->
<?php include 'includes/header.php';?>
<!--/header-->
<div class="projects">
	<div class="container">
		<div class="projects-info">
<div class="page">
	<h3>THANK YOU</h3>
<p>for the interest shown on JP Pet Clinic.</p>
</div>
		</div>
	</div>
</div>
<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
	</body>
</html>
