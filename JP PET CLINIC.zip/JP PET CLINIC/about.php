
<!DOCTYPE html>
<html lang="en">
<head>

<title>JP Pet Clinic</title>
	<meta name="Description" content="" />
  <meta name="Keywords" content="" />		
	<?php include 'includes/csslinks.php';?>
</head>
<body class="aboutPage">
<!--header-->
<?php include 'includes/header.php';?>
<!--/header-->
<!--about-->
<div class="about">
	<div class="container">
		<div class="about-top">
			<div class="about-top-info">
					<h3>About</h3>
					<div class="col-md-4 about-img">
						<img src="images/pic8.jpg" alt=""/>
					</div>
					<div class="col-md-8 about-desc">
						<p>JP Pet specialty hospital was opened in Adyar in 1988 to cater to the needs of the pet lovers in Chennai. <br/>Prof. Dr. R. Jayaprakash, MVSC, Phd, the founder of JP Pet specialty hospital, now has more than 30 years of experience in canine practice.</p>
						<p>At JP Pet specialty Hospital we understand, respect, and appreciate the human-animal bond that we all have with our pets. They are very special members of our families and we treat them as such. We strive to provide the best quality medicine and most current surgical techniques with integrity in a compassionate environment. Thank you for the trust you have placed in caring for your loved one.</p>
						<p>JP Pet specialty Hospital is a full service animal hospital and will take both emergency cases as well as less urgent medical, surgical, and dental issues. Prof. Dr. R. Jayaprakash, MVSC, Phd is experienced in all types of conditions and treatments.</p>
					</div>
					<div class="clearfix"> </div>
			</div>
		</div>
		<div class="about-bottom">
			<div class="about-topgrid1">
				<h3>What To Expect</h3>
				<div class="col-md-8 about-bottom-info">
					<p>When you are looking for a veterinary care clinic you should be able to count on superior care and excellent service.  We at JP Pet specialty Hospital have assembled an expert team of veterinary professionals to bring you the best possible healthcare for your pet.  We have a state-of-the-art veterinary facility, which is clean, comfortable, and efficient.  Call us to schedule an appointment, and we will find a time that is convenient for you.</p>
					<p>Once a year, you should take your pet in for a check-up.  This will include a full physical exam, and may include teeth and gum cleaning if needed. Prof. Dr. R. Jayaprakash, MVSC, Phd will check the health of your pet from head to tail, and you will be very happy you came to JP Pet specialty Hospital for service.</p>
					<p>Bring in any medical history you have for your pet when you come to our vet clinic.  It's best to keep a journal of your pet's health throughout his or her life, including behavioral shifts.  If you have something like this, share it with our team.  If not, let us know everything that you think will be important. Prof. Dr. R. Jayaprakash, MVSC, Phd can still work with whatever information you have.</p>
				</div>
				<div class="col-md-4 about-bottom-info-right">
				  <img src="images/pic9.jpg" alt="" />
			 	</div>
			  <div class="clearfix"> </div>
			</div>
		</div>
		<div class="clearfix"> </div>
	</div>
</div>



<div class="aboutus">
	<div class="container">
		<div class="about-bottom-info">
	<div class="col-md-4 about-left">
		<div class="col-md-3 check-in">
			<img src="images/dg-1.png" alt=""/>
		</div>
		<div class="col-md-9 check-out">
			<h4>Pet Health Care</h4>
			<p>We perform a thorough physical examination to determine the Pet’s state of health.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="col-md-4 about-left">
		<div class="col-md-3 check-in">
			<img src="images/dg-2.png" alt=""/>
		</div>
		<div class="col-md-9 check-out">
			<h4>Specialized Facilities</h4>
				<p>Our Services include, but are not limited to: Ultrasound,X-Ray, On-Screen Exam.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="col-md-4 about-left">
		<div class="col-md-3 check-in">
			<img src="images/dg-3.png" alt=""/>
		</div>
		<div class="col-md-9 check-out">
			<h4>Equiped Operation Theater</h4>
			<p>The team at JP Pet Speciality Hospital are very dedicated and experienced who have.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="clearfix mb50"> </div>
	<div class="col-md-4 about-left">
		<div class="col-md-3 check-in">
			<img src="images/dg-4.png" alt=""/>
		</div>
		<div class="col-md-9 check-out">
			<h4>Pet Spa / Grooming and Bathing</h4>
			<p>Our pet spa is a leader in the pet spa industry. After many years of experience.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="col-md-4 about-left">
		<div class="col-md-3 check-in">
			<img src="images/dg-5.png" alt=""/>
		</div>
		<div class="col-md-9 check-out">
			<h4>Pet Holiday Home</h4>
			<p>It's fun and safe; there’s room to run around, lots of human attention and plenty.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="col-md-4 about-left">
		<div class="col-md-3 check-in">
			<img src="images/dg-6.png" alt=""/>
		</div>
		<div class="col-md-9 check-out">
			<h4>Pet Shop</h4>
			<p>We have been serving the animals of Chennai, Coimbatore and beyond for almost 25 years.</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="clearfix"> </div>
</div>
	</div>
	</div>
</div>
<!--/about-->
<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
	</body>
</html>
