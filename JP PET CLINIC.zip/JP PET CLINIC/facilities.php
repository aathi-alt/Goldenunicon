<!DOCTYPE html>
<html lang="en">
<head>
<title>JP Pet Clinic</title>
	<meta name="Description" content="" />
  <meta name="Keywords" content="" />		
	<?php include 'includes/csslinks.php';?>
</head>
<body class="facilitiesPage">
<!--header-->
<?php include 'includes/header.php';?>
<!--/header-->
<div class="support_top">
	<div class="container">
		<h4>Facilities</h4>
			<div class="support-info">
				<div class="col-md-4 support-info-top">
					<p>Swimming is a great exercise for dogs, and that is why we built the only outdoor dog pool in Chennai for use in the summer months. It provides great cardiovascular and muscular training with no impact on the joints, which is especially great for older and overweight dogs. In addition, many dogs (including retrieving breeds) do not know how to swim or can only swim short distances before tiring. Our pool area will give them all the space they need to swim around under the supervision of our lifeguards. All dogs will receive a thorough towel dry upon leaving their pool session.  All dogs must be fully vaccinated for rabies, bordetella and DHLPP to swim in the pool. If your dog is inexperienced at swimming, they must use our private instructor for their first swim. Parents are welcome to watch their dog swim.</p>
				</div>
				<div class="col-md-8 support-info-bottom">
					<div class="vdoMain">
					  <video playsinline="" controls controlsList="nodownload"><source src="images/dog-swimming.mp4" type="video/mp4"></video>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
	 </div>
</div>



<div class="support-bottom">
	<div class="container">
		<div class="col-md-4 col-sm-4 support-bottom-top">
			<img src="images/c1.jpg" />
			<div class="grid-bottom">
				<h3>Pet Holiday Home</h3>						
			</div>
		</div>
		<div class="col-md-4 col-sm-4 support-bottom-top">
			<img src="images/c2.jpg" />
			<div class="grid-bottom">
				<h3>Pet Pharmacy and Store</h3>
			</div>
		</div>
		<div class="col-md-4 col-sm-4 support-bottom-top">
			<img src="images/c3.jpg" />
			<div class="grid-bottom">
				<h3>Pet Store</h3>
			</div>
		</div>
		<div class="clearfix mb50"> </div>
		<div class="col-md-4 col-sm-4 support-bottom-top">
			<img src="images/c4.jpg" />
			<div class="grid-bottom">
				<h3>Waiting Room 1</h3>
			</div>
		</div>
		<div class="col-md-4 col-sm-4 support-bottom-top">
			<img src="images/c5.jpg" />
			<div class="grid-bottom">
				<h3>Waiting Room 2</h3>
			</div>
		</div>
		<div class="col-md-4 col-sm-4 support-bottom-top">
			<img src="images/c6.jpg" />
			<div class="grid-bottom">
				<h3>Consulting Room</h3>
			</div>
		</div>
	</div>
</div>




<!--footer-->
<?php include 'includes/footer.php';?>
<!--/footer-->
	</body>
</html>
